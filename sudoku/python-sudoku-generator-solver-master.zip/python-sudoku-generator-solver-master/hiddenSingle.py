def hiddenSingle(cell):
    pos = cell.checkPosition()
    row+ = pos[1]+1
    for 
